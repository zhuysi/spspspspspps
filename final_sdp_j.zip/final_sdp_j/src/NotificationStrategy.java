public interface NotificationStrategy {
    void sendNotification(String message);
}
