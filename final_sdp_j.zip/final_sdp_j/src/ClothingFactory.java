public interface ClothingFactory {
    Clothing createClothing(String type, String color, String size, String brand, double price);

    Clothing createClothing(String clothingType, String черный, String adidas);
}
