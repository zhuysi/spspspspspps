// 3. Adapter (Adapter)
public interface DisplayAdapter {
    void displayClothing(Clothing clothing);
}
