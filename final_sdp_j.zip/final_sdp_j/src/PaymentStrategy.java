// 5. Strategy
public interface PaymentStrategy {
    void pay(double amount);
}
