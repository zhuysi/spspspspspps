// 4. Decorator (Decorator)
public interface ClothingDecorator {
    Clothing decorate(Clothing baseClothing);
}
